import { createClient } from '@base44/sdk';
// import { getAccessToken } from '@base44/sdk/utils/auth-utils';

// Create a client with authentication required
export const base44 = createClient({
  appId: "68a127aa13e2fa5ab28a16d8", 
  requiresAuth: true // Ensure authentication is required for all operations
});
