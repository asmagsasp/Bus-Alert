import { base44 } from './base44Client';


export const BusAlarm = base44.entities.BusAlarm;



// auth sdk:
export const User = base44.auth;