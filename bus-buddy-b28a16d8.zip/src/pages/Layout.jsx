
import React, { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { SidebarProvider, useSidebar } from "@/components/SidebarContext";
import { Button } from "@/components/ui/button";
import { Menu, X, Home, Settings, Bus } from "lucide-react";

function Sidebar() {
  const { isOpen, toggleSidebar } = useSidebar();

  const menuItems = [
    { name: "BusAlarm", label: "Alarme", icon: Bus, path: "/BusAlarm" },
    { name: "Settings", label: "Configurações", icon: Settings, path: "/Settings" },
  ];

  return (
    <>
      <div className={`fixed inset-y-0 left-0 z-40 w-64 bg-slate-800 text-white transform ${isOpen ? "translate-x-0" : "-translate-x-full"} transition-transform duration-300 ease-in-out md:translate-x-0`}>
        <div className="p-4 flex justify-between items-center md:hidden">
          <h2 className="text-xl font-bold">BusAlert</h2>
          <Button variant="ghost" size="icon" onClick={toggleSidebar}>
            <X className="h-6 w-6" />
          </Button>
        </div>
        <nav className="mt-10">
          {menuItems.map((item) => (
            <Link
              key={item.name}
              to={createPageUrl(item.name)}
              className="flex items-center px-4 py-3 text-lg hover:bg-slate-700 transition-colors"
              onClick={toggleSidebar}
            >
              <item.icon className="mr-3 h-5 w-5" />
              {item.label}
            </Link>
          ))}
        </nav>
      </div>
      {isOpen && <div className="fixed inset-0 bg-black/60 z-30 md:hidden" onClick={toggleSidebar}></div>}
    </>
  );
}

function Header({ currentPageName }) {
  const { toggleSidebar } = useSidebar();
  const location = useLocation();
  const pageTitles = {
    BusAlarm: "BusAlert - Alarme de Ônibus",
    Settings: "Configurações",
  };
  const title = pageTitles[currentPageName] || "BusAlert";

  return (
    <header className="bg-white shadow-sm md:ml-64">
      <div className="max-w-7xl mx-auto py-4 px-4 sm:px-6 lg:px-8 flex items-center">
        <Button variant="ghost" size="icon" className="md:hidden mr-2" onClick={toggleSidebar}>
          <Menu className="h-6 w-6" />
        </Button>
        <h1 className="text-xl font-semibold text-gray-800">{title}</h1>
      </div>
    </header>
  );
}

export default function Layout({ children, currentPageName }) {
  return (
    <SidebarProvider>
      <div className="min-h-screen bg-slate-100">
        <Sidebar />
        <div className="flex flex-col">
          <Header currentPageName={currentPageName} />
          <main className="md:ml-64 p-4">{children}</main>
        </div>
      </div>
    </SidebarProvider>
  );
}
