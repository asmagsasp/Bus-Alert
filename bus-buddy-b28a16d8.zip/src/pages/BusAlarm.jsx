
import React, { useState, useEffect, useRef } from "react";
import { BusAlarm } from "@/api/entities";
import { User } from "@/api/entities";
import LocationInput from "../components/LocationInput";
import AlarmStatus from "../components/AlarmStatus";
import LocationPermission from "../components/LocationPermission";
import AlarmNotification from "../components/AlarmNotification";

export default function BusAlarmPage() {
  const [currentAlarm, setCurrentAlarm] = useState(null);
  const [currentLocation, setCurrentLocation] = useState(null);
  const [distance, setDistance] = useState(null);
  const [isMonitoring, setIsMonitoring] = useState(false);
  const [hasLocationPermission, setHasLocationPermission] = useState(false);
  const [permissionDenied, setPermissionDenied] = useState(false);
  const [showAlarmNotification, setShowAlarmNotification] = useState(false);
  const [alarmSoundUrl, setAlarmSoundUrl] = useState(null);
  const watchIdRef = useRef(null);
  const intervalRef = useRef(null);
  const alarmRef = useRef(null);

  useEffect(() => {
    checkLocationPermission();
    loadCurrentAlarm();
    return () => {
      stopLocationMonitoring();
    };
  }, []);

  useEffect(() => {
    alarmRef.current = currentAlarm;
  }, [currentAlarm]);

  const checkLocationPermission = async () => {
    if (!navigator.geolocation) {
      setPermissionDenied(true);
      return;
    }

    try {
      const position = await getCurrentPosition();
      setHasLocationPermission(true);
      setCurrentLocation({
        latitude: position.coords.latitude,
        longitude: position.coords.longitude
      });
    } catch (error) {
      setPermissionDenied(true);
      setHasLocationPermission(false);
    }
  };

  const getCurrentPosition = () => {
    return new Promise((resolve, reject) => {
      navigator.geolocation.getCurrentPosition(resolve, reject, {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 0
      });
    });
  };

  const loadCurrentAlarm = async () => {
    try {
      const user = await User.me();
      setAlarmSoundUrl(user.custom_alarm_sound_url);
      const alarms = await BusAlarm.filter({ created_by: user.email }, '-created_date', 1);
      
      if (alarms.length > 0) {
        const latestAlarm = alarms[0];

        // Correção: Se o app foi fechado durante o monitoramento, 
        // reinicia o status para "inativo" ao carregar.
        if (latestAlarm.status === "monitoring") {
          await BusAlarm.update(latestAlarm.id, { status: "inactive" });
          latestAlarm.status = "inactive"; // Atualiza o objeto local também
        }
        
        setCurrentAlarm(latestAlarm);
        // A lógica que iniciava o monitoramento automaticamente foi removida.
      }
    } catch (error) {
      console.error("Erro ao carregar alarme:", error);
    }
  };

  const calculateDistance = (lat1, lon1, lat2, lon2) => {
    console.log("=== CALCULANDO DISTÂNCIA ===");
    console.log("Inputs originais:", {lat1, lon1, lat2, lon2});
    
    // Converter para números garantindo que não há problemas de tipo
    const numLat1 = Number(lat1);
    const numLon1 = Number(lon1);
    const numLat2 = Number(lat2);
    const numLon2 = Number(lon2);

    console.log("Depois da conversão:", {numLat1, numLon1, numLat2, numLon2});

    // Validações rigorosas
    if (isNaN(numLat1) || isNaN(numLon1) || isNaN(numLat2) || isNaN(numLon2)) {
      console.error("Coordenadas inválidas após conversão");
      return null;
    }

    if (Math.abs(numLat1) > 90 || Math.abs(numLat2) > 90) {
      console.error("Latitudes fora do range válido");
      return null;
    }

    if (Math.abs(numLon1) > 180 || Math.abs(numLon2) > 180) {
      console.error("Longitudes fora do range válido");
      return null;
    }

    // Fórmula de Haversine mais precisa
    const R = 6371000; // Raio da Terra em metros
    const toRadians = (degrees) => degrees * (Math.PI / 180);
    
    const dLat = toRadians(numLat2 - numLat1);
    const dLon = toRadians(numLon2 - numLon1);
    const radLat1 = toRadians(numLat1);
    const radLat2 = toRadians(numLat2);

    console.log("Diferenças em radianos:", {dLat, dLon, radLat1, radLat2});

    const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
              Math.cos(radLat1) * Math.cos(radLat2) *
              Math.sin(dLon/2) * Math.sin(dLon/2);
    
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    const distance = R * c;
    
    console.log("Cálculos intermediários:", {a, c, distance});
    console.log("Distância final:", Math.round(distance), "metros");
    console.log("=== FIM CÁLCULO ===");
    
    return Math.round(distance);
  };

  const handleLocationSet = async (locationData) => {
    try {
      const user = await User.me();
      
      if (currentAlarm) {
        await BusAlarm.delete(currentAlarm.id);
      }

      const newAlarm = await BusAlarm.create({
        destination_address: locationData.address,
        destination_latitude: locationData.latitude,
        destination_longitude: locationData.longitude,
        alert_distance: locationData.distance,
        status: "inactive"
      });

      setCurrentAlarm(newAlarm);
    } catch (error) {
      console.error("Erro ao salvar alarme:", error);
      alert("Erro ao salvar destino. Tente novamente.");
    }
  };

  const startLocationMonitoring = () => {
    if (!hasLocationPermission || !alarmRef.current) return;

    setIsMonitoring(true);
    
    BusAlarm.update(alarmRef.current.id, { status: "monitoring" });
    setCurrentAlarm(prev => ({ ...prev, status: "monitoring" }));

    watchIdRef.current = navigator.geolocation.watchPosition(
      (position) => {
        if (!alarmRef.current) return;

        const newLocation = {
          latitude: position.coords.latitude,
          longitude: position.coords.longitude
        };
        setCurrentLocation(newLocation);

        const fromCoords = { lat: newLocation.latitude, lon: newLocation.longitude };
        const toCoords = { lat: alarmRef.current.destination_latitude, lon: alarmRef.current.destination_longitude };

        const currentDistance = calculateDistance(
          fromCoords.lat,
          fromCoords.lon,
          toCoords.lat,
          toCoords.lon
        );
        
        setDistance(currentDistance);

        if (currentDistance !== null && currentDistance <= alarmRef.current.alert_distance) {
          triggerAlarm();
        }
      },
      (error) => {
        console.error("Erro de geolocalização:", error);
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 0
      }
    );
  };

  const stopLocationMonitoring = () => {
    setIsMonitoring(false);
    
    if (watchIdRef.current) {
      navigator.geolocation.clearWatch(watchIdRef.current);
      watchIdRef.current = null;
    }

    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }

    if (alarmRef.current) {
      BusAlarm.update(alarmRef.current.id, { status: "inactive" });
      setCurrentAlarm(prev => ({ ...prev, status: "inactive" }));
    }
  };

  const triggerAlarm = async () => {
    setShowAlarmNotification(true);
    
    if (!alarmRef.current) return;
    await BusAlarm.update(alarmRef.current.id, { status: "arrived" });
    setCurrentAlarm(prev => ({ ...prev, status: "arrived" }));
    
    stopLocationMonitoring();
  };

  const handleRequestPermission = () => {
    setPermissionDenied(false);
    checkLocationPermission();
  };

  const dismissAlarmNotification = () => {
    setShowAlarmNotification(false);
    if (alarmRef.current) {
      BusAlarm.update(alarmRef.current.id, { status: "inactive" });
      setCurrentAlarm(prev => ({ ...prev, status: "inactive" }));
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 p-4 md:p-8">
      <div className="max-w-2xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-slate-800 mb-2">
            Alarme do Ônibus
          </h1>
          <p className="text-slate-600 text-lg">
            Configure seu destino e seja alertado quando chegar
          </p>
        </div>

        <div className="space-y-6">
          <LocationPermission 
            onRequestPermission={handleRequestPermission}
            hasPermission={hasLocationPermission}
            permissionDenied={permissionDenied}
          />

          {hasLocationPermission && (
            <>
              <LocationInput
                onLocationSet={handleLocationSet}
                isDisabled={isMonitoring}
                currentLocation={currentLocation}
              />

              <AlarmStatus
                alarm={currentAlarm}
                currentLocation={currentLocation}
                distance={distance}
                onStartMonitoring={startLocationMonitoring}
                onStopMonitoring={stopLocationMonitoring}
                isMonitoring={isMonitoring}
              />
            </>
          )}
        </div>

        <AlarmNotification
          isVisible={showAlarmNotification}
          destination={currentAlarm?.destination_address}
          onDismiss={dismissAlarmNotification}
          soundUrl={alarmSoundUrl}
        />
      </div>
    </div>
  );
}
