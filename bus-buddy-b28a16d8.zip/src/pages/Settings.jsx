import React, { useState, useEffect } from 'react';
import { User } from '@/api/entities';
import { UploadFile } from '@/api/integrations';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Music, Trash2, Loader2, UploadCloud } from 'lucide-react';

export default function SettingsPage() {
  const [user, setUser] = useState(null);
  const [selectedFile, setSelectedFile] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [currentSoundUrl, setCurrentSoundUrl] = useState(null);

  useEffect(() => {
    async function loadUser() {
      try {
        const currentUser = await User.me();
        setUser(currentUser);
        setCurrentSoundUrl(currentUser.custom_alarm_sound_url);
      } catch (error) {
        console.error("Erro ao carregar usuário:", error);
      }
    }
    loadUser();
  }, []);

  const handleFileChange = (event) => {
    setSelectedFile(event.target.files[0]);
  };

  const handleUpload = async () => {
    if (!selectedFile) {
      alert("Por favor, selecione um arquivo MP3.");
      return;
    }
    setIsLoading(true);
    try {
      const { file_url } = await UploadFile({ file: selectedFile });
      await User.updateMyUserData({ custom_alarm_sound_url: file_url });
      setCurrentSoundUrl(file_url);
      alert("Som de alarme atualizado com sucesso!");
    } catch (error) {
      console.error("Erro ao fazer upload:", error);
      alert("Ocorreu um erro ao enviar seu arquivo. Tente novamente.");
    }
    setIsLoading(false);
    setSelectedFile(null);
  };

  const handleRemoveSound = async () => {
    setIsLoading(true);
    try {
      await User.updateMyUserData({ custom_alarm_sound_url: null });
      setCurrentSoundUrl(null);
      alert("Som personalizado removido.");
    } catch (error) {
      console.error("Erro ao remover som:", error);
      alert("Ocorreu um erro ao remover o som. Tente novamente.");
    }
    setIsLoading(false);
  };

  return (
    <div className="p-4 md:p-8">
      <div className="max-w-2xl mx-auto">
        <h1 className="text-3xl font-bold text-slate-800 mb-6">Configurações</h1>
        
        <div className="p-6 bg-white rounded-2xl shadow-lg border border-slate-200/60 space-y-6">
          <h2 className="text-xl font-semibold text-slate-700">Som do Alarme Personalizado</h2>
          
          {currentSoundUrl ? (
            <div className="p-4 bg-green-50 rounded-xl border border-green-200 space-y-4">
              <div className="flex items-center gap-3">
                <Music className="w-5 h-5 text-green-700" />
                <p className="text-green-800 font-medium">Você tem um som personalizado configurado.</p>
              </div>
              <audio src={currentSoundUrl} controls className="w-full" />
              <Button onClick={handleRemoveSound} variant="destructive" size="sm" disabled={isLoading}>
                {isLoading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Trash2 className="w-4 h-4 mr-2" />}
                Remover Som
              </Button>
            </div>
          ) : (
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-4">
              <Label htmlFor="sound-upload" className="font-medium text-slate-700">
                Selecione um arquivo MP3
              </Label>
              <div className="flex flex-col sm:flex-row gap-3">
                <Input id="sound-upload" type="file" accept=".mp3" onChange={handleFileChange} className="flex-grow"/>
                <Button onClick={handleUpload} disabled={isLoading || !selectedFile} className="bg-blue-600 hover:bg-blue-700">
                  {isLoading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <UploadCloud className="w-4 h-4 mr-2" />}
                  Enviar
                </Button>
              </div>
              {selectedFile && <p className="text-sm text-slate-500">Arquivo selecionado: {selectedFile.name}</p>}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}