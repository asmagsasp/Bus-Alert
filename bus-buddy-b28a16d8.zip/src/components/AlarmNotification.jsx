import React, { useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { AlertCircle, MapPin, X } from "lucide-react";
import { Button } from "@/components/ui/button";

const DEFAULT_ALARM_SOUND = "data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmAVADqX2u/HdSYCKgUCL/vNdSYCKwUCL/vNdSYCKgUCL/vNdykIGFyk6feXRw4SSmDj8LdmHgM6ktXwy3gqBSp+zPLaizsLHlmx6+OZUTE=";

export default function AlarmNotification({ isVisible, destination, onDismiss, soundUrl }) {
  const audioRef = useRef(null);

  useEffect(() => {
    if (isVisible) {
      if (audioRef.current) {
        audioRef.current.src = soundUrl || DEFAULT_ALARM_SOUND;
        audioRef.current.loop = true;
        audioRef.current.play().catch(e => console.error("Audio playback failed:", e));
        
        if (navigator.vibrate) {
          navigator.vibrate([500, 250, 500, 250, 500, 250, 500, 250, 500]);
        }
      }
    } else {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current.currentTime = 0;
        if (navigator.vibrate) {
          navigator.vibrate(0);
        }
      }
    }
  }, [isVisible, soundUrl]);

  return (
    <>
      <audio ref={audioRef} />
      <AnimatePresence>
        {isVisible && (
          <motion.div
            initial={{ opacity: 0, y: 100 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 100 }}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
            className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center p-4 z-50"
          >
            <div className="bg-white rounded-2xl shadow-2xl p-6 w-full max-w-md text-center">
              <div className="flex justify-center mb-4">
                <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center">
                  <AlertCircle className="text-red-500 w-10 h-10" />
                </div>
              </div>
              <h2 className="text-2xl font-bold text-slate-800 mb-2">Chegando ao Destino!</h2>
              <p className="text-slate-600 mb-4">
                Você está próximo de:
              </p>
              <div className="flex items-center justify-center gap-2 bg-slate-100 p-3 rounded-lg mb-6">
                <MapPin className="w-5 h-5 text-slate-500" />
                <p className="font-semibold text-slate-700">{destination || "seu destino"}</p>
              </div>
              <Button
                onClick={onDismiss}
                className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-3 text-lg rounded-lg"
              >
                Parar Alarme
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}