import React from "react";
import { Button } from "@/components/ui/button";
import { MapPin, AlertTriangle } from "lucide-react";

export default function LocationPermission({ onRequestPermission, hasPermission, permissionDenied }) {
  if (hasPermission) return null;

  return (
    <div className="p-6 bg-white rounded-2xl shadow-lg border border-slate-200/60 mb-6">
      <div className="text-center space-y-4">
        <div className="w-16 h-16 bg-orange-100 rounded-2xl flex items-center justify-center mx-auto">
          {permissionDenied ? (
            <AlertTriangle className="w-8 h-8 text-orange-600" />
          ) : (
            <MapPin className="w-8 h-8 text-orange-600" />
          )}
        </div>
        
        <div>
          <h3 className="text-xl font-bold text-slate-800 mb-2">
            {permissionDenied ? "Permissão Negada" : "Acesso à Localização"}
          </h3>
          <p className="text-slate-600 max-w-md mx-auto">
            {permissionDenied 
              ? "Para usar o alarme do ônibus, você precisa permitir o acesso à sua localização nas configurações do navegador."
              : "Para funcionar corretamente, o app precisa acessar sua localização atual."
            }
          </p>
        </div>

        <Button
          onClick={onRequestPermission}
          className="bg-gradient-to-r from-orange-600 to-orange-700 hover:from-orange-700 hover:to-orange-800 text-white font-semibold rounded-xl px-8 py-3"
        >
          <MapPin className="w-5 h-5 mr-2" />
          {permissionDenied ? "Tentar Novamente" : "Permitir Localização"}
        </Button>
      </div>
    </div>
  );
}