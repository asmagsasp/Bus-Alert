
import React from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Play, Square, MapPin, AlertCircle } from "lucide-react";
import { motion } from "framer-motion";

export default function AlarmStatus({ 
  alarm, 
  currentLocation, 
  distance, 
  onStartMonitoring, 
  onStopMonitoring,
  isMonitoring 
}) {
  const getStatusColor = (status) => {
    switch (status) {
      case "monitoring":
        return "bg-green-100 text-green-800 border-green-200";
      case "arrived":
        return "bg-red-100 text-red-800 border-red-200";
      default:
        return "bg-slate-100 text-slate-600 border-slate-200";
    }
  };

  const getStatusText = (status) => {
    switch (status) {
      case "monitoring":
        return "Monitorando";
      case "arrived":
        return "Chegou!";
      default:
        return "Inativo";
    }
  };

  if (!alarm) {
    return (
      <div className="p-6 bg-white rounded-2xl shadow-lg border border-slate-200/60">
        <div className="text-center py-8">
          <MapPin className="w-16 h-16 text-slate-300 mx-auto mb-4" />
          <p className="text-slate-500">Configure um destino para começar</p>
        </div>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6 p-6 bg-white rounded-2xl shadow-lg border border-slate-200/60"
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
            alarm.status === "monitoring" ? "bg-green-100" : 
            alarm.status === "arrived" ? "bg-red-100" : "bg-slate-100"
          }`}>
            {alarm.status === "arrived" ? (
              <AlertCircle className="w-5 h-5 text-red-600" />
            ) : (
              <MapPin className="w-5 h-5 text-slate-600" />
            )}
          </div>
          <div>
            <h3 className="font-bold text-slate-800">Status do Alarme</h3>
            <p className="text-sm text-slate-500">Monitoramento GPS</p>
          </div>
        </div>
        <Badge className={`${getStatusColor(alarm.status)} border font-semibold px-3 py-1`}>
          {getStatusText(alarm.status)}
        </Badge>
      </div>

      <div className="space-y-3">
        <div className="p-4 bg-slate-50 rounded-xl">
          <p className="text-sm font-semibold text-slate-600 mb-1">Destino:</p>
          <p className="text-slate-800">{alarm.destination_address}</p>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="p-4 bg-slate-50 rounded-xl">
            <p className="text-sm font-semibold text-slate-600 mb-1">Alerta em:</p>
            <p className="text-lg font-bold text-slate-800">{alarm.alert_distance}m</p>
          </div>
          <div className="p-4 bg-slate-50 rounded-xl">
            <p className="text-sm font-semibold text-slate-600 mb-1">Distância estimada:</p>
            <p className="text-lg font-bold text-slate-800">
              {distance !== null ? `~${Math.round(distance)}m` : "---"}
            </p>
          </div>
        </div>
      </div>
      
      {isMonitoring && (
        <div className="p-3 bg-green-50 rounded-xl border border-green-200">
          <p className="text-sm text-green-800 text-center font-semibold">
            🟢 Monitoramento Ativo
          </p>
          <p className="text-xs text-green-600 text-center mt-1">
            Você será alertado quando estiver a {alarm.alert_distance}m do destino
          </p>
        </div>
      )}

      <div className="flex gap-3">
        {!isMonitoring ? (
          <Button
            onClick={onStartMonitoring}
            className="flex-1 h-12 bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white font-semibold rounded-xl transition-all duration-300"
          >
            <Play className="w-5 h-5 mr-2" />
            Iniciar Monitoramento
          </Button>
        ) : (
          <Button
            onClick={onStopMonitoring}
            variant="outline"
            className="flex-1 h-12 border-red-300 text-red-700 hover:bg-red-50 font-semibold rounded-xl transition-all duration-300"
          >
            <Square className="w-5 h-5 mr-2" />
            Parar Monitoramento
          </Button>
        )}
      </div>
    </motion.div>
  );
}
