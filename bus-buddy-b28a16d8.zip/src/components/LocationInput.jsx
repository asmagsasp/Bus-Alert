import React, { useState, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { MapPin, Search, Target, Crosshair } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function LocationInput({ onLocationSet, isDisabled, currentLocation }) {
  const [address, setAddress] = useState("");
  const [distance, setDistance] = useState("300"); // Aumentado para 300m por padrão
  const [isSearching, setIsSearching] = useState(false);
  const [searchResults, setSearchResults] = useState([]);
  
  const [manualLat, setManualLat] = useState("");
  const [manualLon, setManualLon] = useState("");
  const [manualAddress, setManualAddress] = useState("");
  const [detectedCity, setDetectedCity] = useState("");

  useEffect(() => {
    if (currentLocation) {
      fetchCityName(currentLocation.latitude, currentLocation.longitude);
    }
  }, [currentLocation]);

  const fetchCityName = async (lat, lon) => {
    try {
      const response = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lon}`);
      const data = await response.json();
      if (data && data.address) {
        const city = data.address.city || data.address.town || data.address.village || data.address.suburb || "";
        setDetectedCity(city);
      }
    } catch (error) {
      console.error("Erro ao detectar a cidade:", error);
    }
  };

  const calculateDistance = (lat1, lon1, lat2, lon2) => {
    const R = 6371000;
    const toRadians = (degrees) => degrees * (Math.PI / 180);
    const φ1 = toRadians(lat1);
    const φ2 = toRadians(lat2);
    const Δφ = toRadians(lat2 - lat1);
    const Δλ = toRadians(lon2 - lon1);

    const a = Math.sin(Δφ/2) * Math.sin(Δφ/2) +
              Math.cos(φ1) * Math.cos(φ2) *
              Math.sin(Δλ/2) * Math.sin(Δλ/2);
    
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return Math.round(R * c);
  };

  const searchLocation = async () => {
    if (!address.trim()) return;
    
    setIsSearching(true);
    setSearchResults([]);
    
    try {
      let finalQuery = address.trim();
      
      if (detectedCity) {
        finalQuery = `${address}, ${detectedCity}, Brasil`;
      } else {
        finalQuery = `${address}, Brasil`;
      }
      
      let apiUrl = `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(finalQuery)}&limit=15&addressdetails=1&accept-language=pt-BR`;
      
      if (currentLocation) {
        const buffer = 0.5;
        apiUrl += `&viewbox=${currentLocation.longitude - buffer},${currentLocation.latitude + buffer},${currentLocation.longitude + buffer},${currentLocation.latitude - buffer}`;
      }

      const response = await fetch(apiUrl);
      const data = await response.json();
      
      let results = [];
      
      if (data && data.length > 0) {
        results = data.map(item => {
          const lat = parseFloat(item.lat);
          const lon = parseFloat(item.lon);
          let distanceFromCurrent = null;
          
          if (currentLocation) {
            distanceFromCurrent = calculateDistance(
              currentLocation.latitude,
              currentLocation.longitude,
              lat,
              lon
            );
          }
          
          let displayName = item.display_name;
          if (item.address) {
            const parts = [];
            if (item.address.road) parts.push(item.address.road);
            if (item.address.house_number) parts.push(item.address.house_number);
            if (item.address.suburb) parts.push(item.address.suburb);
            if (item.address.city || item.address.town) parts.push(item.address.city || item.address.town);
            if (parts.length > 0) {
              displayName = parts.join(', ');
            }
          }
          
          return {
            display_name: displayName,
            full_address: item.display_name,
            latitude: lat,
            longitude: lon,
            distanceFromCurrent: distanceFromCurrent,
            type: item.type || 'local',
            class: item.class || 'place'
          };
        });

        results = results.filter(result => 
          result.full_address.toLowerCase().includes('brasil') || 
          result.full_address.toLowerCase().includes('brazil')
        );

        if (currentLocation) {
          results.sort((a, b) => {
            if (a.distanceFromCurrent === null && b.distanceFromCurrent === null) return 0;
            if (a.distanceFromCurrent === null) return 1;
            if (b.distanceFromCurrent === null) return -1;
            return a.distanceFromCurrent - b.distanceFromCurrent;
          });
        }

        results = results.slice(0, 10);
        setSearchResults(results);
        
        if (results.length === 0) {
          alert("Nenhum resultado encontrado no Brasil. Tente ser mais específico ou use a aba 'Coordenadas'.");
        }
      } else {
        alert("Nenhum resultado encontrado. Tente ser mais específico ou use a aba 'Coordenadas'.");
      }
    } catch (error) {
      console.error("Erro ao buscar:", error);
      alert("Erro ao buscar endereço. Tente novamente.");
    }
    setIsSearching(false);
  };

  const selectLocation = (result) => {
    const location = {
      address: result.display_name,
      latitude: result.latitude,
      longitude: result.longitude,
      distance: parseInt(distance, 10) || 300
    };
    onLocationSet(location);
    setSearchResults([]);
    setAddress("");
  };

  const handleManualCoordinates = () => {
    const lat = parseFloat(manualLat.replace(',', '.'));
    const lon = parseFloat(manualLon.replace(',', '.'));
    
    if (isNaN(lat) || isNaN(lon) || lat < -90 || lat > 90 || lon < -180 || lon > 180) {
      alert("Por favor, insira coordenadas válidas.");
      return;
    }
    
    if (!manualAddress.trim()) {
      alert("Por favor, insira uma descrição do local.");
      return;
    }
    
    const location = {
      address: manualAddress,
      latitude: lat,
      longitude: lon,
      distance: parseInt(distance, 10) || 300
    };
    onLocationSet(location);
    setManualLat("");
    setManualLon("");
    setManualAddress("");
  };

  const useCurrentLocation = () => {
    if (!currentLocation) {
      alert("Localização atual não disponível.");
      return;
    }
    
    const location = {
      address: `Teste de Precisão GPS`,
      latitude: currentLocation.latitude,
      longitude: currentLocation.longitude,
      distance: parseInt(distance, 10) || 300
    };
    
    onLocationSet(location);
  };

  return (
    <div className="p-6 bg-white rounded-2xl shadow-lg border border-slate-200/60">
      <div className="mb-4 p-3 bg-amber-50 rounded-xl border border-amber-200">
        <p className="text-sm text-amber-800 font-semibold mb-1">💡 Dica de Uso:</p>
        <p className="text-xs text-amber-700">
          GPS tem margem de erro natural. Para melhor resultado, use distâncias de 200-500m e teste antes da viagem real.
        </p>
      </div>

      {currentLocation && (
        <div className="mb-4 p-3 bg-green-50 rounded-xl border border-green-200">
          <p className="text-sm text-green-800 mb-2 font-semibold">🔧 Teste de Precisão:</p>
          <Button
            onClick={useCurrentLocation}
            disabled={isDisabled}
            variant="outline"
            className="w-full border-green-300 text-green-700 hover:bg-green-100"
          >
            <Crosshair className="w-4 h-4 mr-2" />
            Testar com Minha Localização Atual
          </Button>
          <p className="text-xs text-green-600 mt-1">
            Use isso para ver qual margem de erro seu GPS tem agora
          </p>
        </div>
      )}

      <Tabs defaultValue="search" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="search">🔍 Buscar Endereço</TabsTrigger>
          <TabsTrigger value="manual">📍 Coordenadas Exatas</TabsTrigger>
        </TabsList>
        
        <TabsContent value="search" className="pt-6 space-y-4">
          <div className="space-y-2">
            <Label>Endereço de Destino</Label>
            <div className="flex gap-2">
              <Input 
                placeholder="Ex: Rua Santos, 123 ou Shopping Center Norte" 
                value={address} 
                onChange={(e) => setAddress(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && searchLocation()}
                disabled={isDisabled} 
              />
              <Button onClick={searchLocation} disabled={isSearching || !address.trim() || isDisabled}>
                <Search className="w-4 h-4" />
              </Button>
            </div>
            {detectedCity && <p className="text-xs text-slate-500 text-center pt-1">Buscando em: <strong>{detectedCity}</strong></p>}
          </div>
          
          {isSearching && (
            <div className="text-center py-4">
              <div className="inline-block animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600"></div>
              <p className="text-slate-500 mt-2">Buscando endereços...</p>
            </div>
          )}
          
          <div className="space-y-2">
            {searchResults.map((result, index) => (
              <div key={index} onClick={() => selectLocation(result)} className="p-3 bg-slate-50 hover:bg-blue-50 rounded-lg cursor-pointer border transition-colors">
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <p className="font-semibold text-sm text-slate-800">{result.display_name}</p>
                    {result.distanceFromCurrent !== null && (
                      <p className="text-xs text-slate-500 mt-1">
                        Aproximadamente {result.distanceFromCurrent}m da sua localização atual
                      </p>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="manual" className="pt-6 space-y-4">
          <div className="p-4 bg-blue-50 rounded-xl space-y-3">
            <h3 className="font-semibold text-blue-900">Para máxima precisão:</h3>
            <ol className="text-sm text-blue-800 space-y-1 ml-4 list-decimal">
              <li>Abra o Google Maps</li>
              <li>Encontre seu destino exato</li>
              <li>Clique no local e copie as coordenadas</li>
              <li>Cole nos campos abaixo</li>
            </ol>
          </div>

          <div className="space-y-2">
            <Label>Descrição do Local</Label>
            <Input placeholder="Ex: Entrada do Shopping, Ponto de Ônibus da Rua X" value={manualAddress} onChange={(e) => setManualAddress(e.target.value)} disabled={isDisabled} />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>Latitude</Label>
              <Input placeholder="-22.7354416" value={manualLat} onChange={(e) => setManualLat(e.target.value)} disabled={isDisabled} />
            </div>
            <div className="space-y-2">
              <Label>Longitude</Label>
              <Input placeholder="-47.3955621" value={manualLon} onChange={(e) => setManualLon(e.target.value)} disabled={isDisabled} />
            </div>
          </div>
          <Button onClick={handleManualCoordinates} disabled={!manualLat || !manualLon || !manualAddress || isDisabled} className="w-full">
            <Target className="w-5 h-5 mr-2" /> Definir Destino
          </Button>
        </TabsContent>
      </Tabs>

      <div className="border-t pt-4 mt-6 space-y-3">
        <Label>Distância para Alerta (metros)</Label>
        <div className="flex gap-2 mb-2">
          <Button 
            type="button" 
            variant="outline" 
            size="sm" 
            onClick={() => setDistance("200")}
            className={distance === "200" ? "bg-blue-100 border-blue-300" : ""}
          >
            200m
          </Button>
          <Button 
            type="button" 
            variant="outline" 
            size="sm" 
            onClick={() => setDistance("300")}
            className={distance === "300" ? "bg-blue-100 border-blue-300" : ""}
          >
            300m
          </Button>
          <Button 
            type="button" 
            variant="outline" 
            size="sm" 
            onClick={() => setDistance("500")}
            className={distance === "500" ? "bg-blue-100 border-blue-300" : ""}
          >
            500m
          </Button>
        </div>
        <Input 
          type="number" 
          min="100" 
          max="1000" 
          value={distance} 
          onChange={(e) => setDistance(e.target.value)} 
          disabled={isDisabled}
          placeholder="ou digite uma distância personalizada"
        />
        <p className="text-xs text-slate-500">
          Recomendado: 300-500m para compensar imprecisões do GPS
        </p>
      </div>
    </div>
  );
}